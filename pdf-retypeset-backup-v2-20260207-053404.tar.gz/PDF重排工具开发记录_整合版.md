# PDF重排工具开发记录

**项目**: 扫描版PDF字块放大重排工具  
**开发时间**: 2026年2月6日  
**目标**: 将扫描版PDF的字块放大重排，便于阅读

---

## 项目位置

```
/home/wu/桌面/pdf-retypeset/          # GUI版本
/home/wu/clawd/pdf_rearranger_new/    # 命令行版本
```

---

## 核心功能

将扫描版PDF的字块放大重排，核心是**字块检测和顺序保持**，不是OCR识别内容。

---

## 技术方案演进

### 第一版：连通域分析（失败）
- 使用OpenCV连通域分析检测字块
- 问题：扫描版PDF笔画断开，一个字被分成多个连通域
- 结果：字块位置错乱

### 第二版：形态学操作（效果不佳）
- 尝试膨胀+腐蚀连接断开笔画
- 问题：参数难以调整，不同页面效果差异大

### 第三版：OCR边界框检测（GUI版本）
- 使用pytesseract检测文字边界框
- **不需要识别准确**，只用OCR的位置检测能力
- OCR自带行/块信息，顺序天然正确
- 缺点：处理较慢（每页需OCR）

### 第四版：自适应连通域分析（命令行版本）
- 解决了原版重排工具失败的问题
- 使用Otsu自动阈值 + 连通域分析
- 根据组件数量估算字数，自适应调整参数
- 带重试机制确保>50%检测率

---

## 核心算法

### OCR版本（GUI）
```
1. PDF转图像 (pdf2image, 300dpi)
2. OCR检测边界框 (pytesseract.image_to_data)
3. 按行分组，每行内按x坐标排序
4. 提取字块图像，放大后重新布局
5. 输出PDF (PyMuPDF)
```

### 自适应版本（命令行）
```
1. 页面分析 → 估算当前页字数（自适应）
2. 动态调整 → 根据字数调整检测参数
3. 字符切割 → 切割字块为独立图像
4. 重新排版 → 横版布局，分散多行排列
```

---

## 项目结构

### GUI版本
```
pdf-retypeset/
├── src/
│   ├── __init__.py
│   ├── main.py          # CLI入口
│   ├── gui.py           # Tkinter GUI
│   ├── config.py        # 配置管理
│   ├── pipeline.py      # 处理流水线
│   ├── preprocessor.py  # 图像预处理
│   ├── segmenter.py     # 字块分割（OCR）
│   ├── layouter.py      # 重新布局
│   └── output.py        # PDF输出
├── config.yaml
└── requirements.txt
```

### 命令行版本
```
pdf_rearranger_new/
└── pdf_rearranger.py    # 主文件（约730行）
```

**核心类**:
- `CharBlock` - 字符块数据类
- `PageAnalyzer` - 页面分析器
- `CharSegmenter` - 字符切割器
- `LayoutRearranger` - 布局重排器
- `PDFRearranger` - PDF重排主类

---

## 使用方法

### GUI版本
```bash
cd /home/wu/桌面/pdf-retypeset

# 启动GUI
python3 -m src.main --gui

# 命令行处理
python3 -m src.main 输入.pdf 输出.pdf --scale 2.0
```

### 命令行版本
```bash
cd ~/clawd/pdf_rearranger_new

# 基本用法
python3 pdf_rearranger.py input.pdf output.pdf

# 指定放大倍数
python3 pdf_rearranger.py input.pdf output.pdf --zoom 2.0

# 启用调试输出
python3 pdf_rearranger.py input.pdf output.pdf --debug
```

---

## 依赖

### Python包
```
opencv-python
numpy
Pillow
PyMuPDF
pdf2image
PyYAML
pytesseract
```

### 系统依赖
```bash
sudo apt install poppler-utils tesseract-ocr tesseract-ocr-chi-sim
```

---

## GUI功能

- 布局模式：horizontal（横排）、vertical_rtl（竖排从右到左）
- 放大倍数：1.5x - 3.0x
- 预览分割：查看字块检测结果（不同颜色=不同行）
- 实时预览重排效果

---

## 测试结果

### 测试文件
- 唐诗选注评鉴_第1部分_part1.pdf (14页)
- 唐诗选注评鉴_第1部分_part2.pdf (14页)

### 性能指标

| 版本 | 指标 | 结果 |
|------|------|------|
| OCR版本 | 处理时间 | 14页PDF约需1-2分钟 |
| OCR版本 | 输出文件大小 | 7.36MB |
| 自适应版本 | 页数 | 14页 → 17页 |
| 自适应版本 | 检测率 | 60-100%（逐页不同）|
| 自适应版本 | 字符平均尺寸 | 11x14像素 |
| 自适应版本 | 放大倍数 | 2倍 |
| 自适应版本 | 输出文件大小 | 约70MB |

### 效果对比
- **之前**: 字符压缩在顶部一行，不可读
- **现在**: 字符分散排列多行，横版布局可阅读

---

## 技术要点

1. **自适应参数** - 无需预设每页字数
2. **高检测率** - 重试机制确保>50%检测率
3. **正确阅读顺序** - 竖版转横版逻辑正确
4. **放大显示** - 字符2倍放大，适合阅读

---

## 已知问题

1. OCR处理较慢，14页PDF约需1-2分钟
2. 对于字体特殊或印刷质量差的PDF，OCR边界框可能不准确
3. 竖排古籍支持待完善
4. 字符间距可以进一步调整
5. 可以增加GUI界面
6. 可以优化密集页面的检测率

---

## 关键实现细节

### PageAnalyzer 页面分析器
- 使用Otsu自动阈值 + 连通域分析
- 根据组件数量估算字数（50-1000字范围）
- 分析文本密度和版式类型

### CharSegmenter 字符切割器
- 根据估算字数自动调整参数：
  - 稀疏页面(<100字)：宽松参数，min_width=3
  - 中等密度(100-400字)：平衡参数
  - 密集页面(>400字)：严格参数
- 带重试机制：检测率<50%时自动放宽参数

### LayoutRearranger 布局重排器
- 竖版转横版逻辑：
  - 先按列分组（X坐标）
  - 每列内按Y排序（从上到下）
  - 从右到左读取各列
  - 拼接成横版行布局
- 字符放大2倍
- 自动计算每行字符数