"""
PDF Retypeset - 扫描版PDF字符级分割重排工具

将扫描版PDF中的字符作为独立图片切割，然后重新布局。
核心功能是竖版转横版，支持古籍阅读。
"""

__version__ = "0.1.0"
__author__ = "PDF Retypeset Team"
